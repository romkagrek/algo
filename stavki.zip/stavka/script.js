// Получение текущего баланса из cookies
function getBalance() {
  const balance = document.cookie.split('; ').find(row => row.startsWith('balance='));
  return balance ? parseInt(balance.split('=')[1]) : 0;
}

// Сохранение баланса в cookies
function saveBalance(balance) {
  document.cookie = `balance=${balance}; path=/; max-age=3600`;
}

// Функция для обновления отображаемого баланса
function updateBalanceDisplay() {
  const balance = getBalance();
  document.getElementById('balance').textContent = balance;
}

// Добавление 1000 рублей
function addBalance() {
  let balance = getBalance();
  balance += 1000;
  saveBalance(balance);
  updateBalanceDisplay();
}

// Уменьшение на 1000 рублей
function subtractBalance() {
  let balance = getBalance();
  if (balance >= 1000) {
      balance -= 1000;
  } else {
      alert("Баланс не может быть меньше 0!");
  }
  saveBalance(balance);
  updateBalanceDisplay();
}

// Инициализация приложения
document.addEventListener('DOMContentLoaded', () => {
  // Устанавливаем начальный баланс при загрузке
  updateBalanceDisplay();
  
  // Обработчики событий для кнопок
  document.getElementById('add').addEventListener('click', addBalance);
  document.getElementById('subtract').addEventListener('click', subtractBalance);

  // Сохраняем баланс каждую секунду
  setInterval(() => {
      const balance = getBalance();
      saveBalance(balance);
  }, 1000);
});
